package com.example.flutter_pdf_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
